practise
========

this repo contains the things that i have practise.